
/*
 * Purpose:
 * Define, and declare the DERIVED CLASS OR CHILD CLASS, Savings, derived from 
 * the BASE CLASS OR PARENT CLASS, Account. This means that the Savings class will include 
 * member functions, and variables from its Parent class that are not currently listed 
 * in the Savings class. In which case, the Savings class "inherits" all the member 
 * functions, and member variables of the Account class, with the exception of Constructors,
 * Destructors, and Friends functions. 
 * 
 * Because of this inheritance relationship, the functions, getBalance(), and setBalance() were no longer 
 * necessary to declare, and define at the child level, and automatically inherited, 
 * or added as functions of the Savings class. The member variable, balance is also inherited 
 * from the parent, Account class, and is therefore not listed in the Savings class.
 * 
 * The member functions, deposit, and withdraw were added to the Savings class, functions 
 * which are no longer in the parent class, Account.
 
 @author - Deanna Laquian
 @version 2.0 4/7/2017
 
 @member functions: (which are all set as public, or freely accesses by users of the program)
	Savings()
	Purpose - default constructors are not inherited, and are therefore declared, and defined in the 
	   Derived class level. Constructors allow users to create an object instance of the Derived class Savings, and set or initialize the balance of the Account.
    @param - none
    @return - none

	Savings (double bal) 
	Purpose - constructor that also allows users to create an object instance of the Derived class Savings, but also allows to pass a parameter.
	@param bal - passes a double variable to set/initialize the balance of the account.
    @return - none

	void deposit(double amount)
	Purpose - mutator, that allows users to add money to account. Calculates, and sets new balance of account after addition.
	@param amount - passes as the amount to add to the balance of the account.
	@return - none

	void withdraw(double amount)
	Purpose - mutator, that allows users to subtract money from account. Calculates, and sets new balance of account after subtraction.
    @param amount - passes as the amount to deduct to the balance of the account.
	@return - none

 */

#ifndef SAVINGS_H
#define SAVINGS_H

#include "account.h"

using namespace std;

class Savings: public Account
{
     public:
		Savings();
		Savings(double bal);
		void deposit(double amount);
		void withdraw(double amount);
		//void setBalance(double bal);
		//double getBalance();

    // private:
		//double savings_balance;
    

};

#endif


/* 
 Purpose:
 Define the various member functions declared in account.h
 @member functions - various, see below
 @param - various, see below
 @return - various, see bleow
 */

#include "account.h"

#include <cmath>

/* 
 @member function - Account::Account()
 Purpose - allow users to create an object instance of Account, and set or initialize the balance.
 @param - none
 @return - none
 */

Account::Account()
{
     balance = 0;
}

/* 
 @member function - Account::Account(double bal)
 Purpose - allow users to also create an object instance of Account, pass a double value as bal, which is balance in this context.
 @param double bal - passes a double value as balance of the account.
 @return - none
 */

Account::Account(double bal)
{
     balance = bal;
}

/* 
 @member function - Account::setBalance()
 Purpose - allow users to modify the current balance of the account by passing a double value as bal, then assign the new balance amount to the private 
	member variable, balance.
 @param double bal - passes a double value as the new balance of the account
 @return - none
 */

void Account::setBalance(double bal)
{
     balance = bal;
}

/* 
 @member function - Account::getBalance()
 Purpose - allow users to access the current balance of the account.
 @param - none
 @return - a double value of balance of the account.
 */

double Account::getBalance()
{
     return balance;
}

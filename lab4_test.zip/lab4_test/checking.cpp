
/* 
 Purpose:
 Define the various member functions declared in checking.h
 @member functions - various, see below
 @param - various, see below
 @return - various, see bleow
 */

#include "checking.h"
#include <cmath>
#include <iostream>

using namespace std;

int checkBal;
//Checking checking;
const double penalty = 5.00; 

/* 
 @member function - Checking::Checking()
 Purpose - constructor, noted as a Child of the Parent class, Account. 
	It allows users to create an object instance of Savings. The definition is intentionally left blank.
 @param - none
 @return - none
 */

Checking::Checking() : Account()
{
     
}

/* 
 @member function - Checking::Checking(double bal)
 Purpose - constructor, also noted as a Child of the constructor of Parent class, Account. 
	It allow users to also create an object instance of Account, pass a double value as bal, which is balance in this context. 
	It is also intentionally left blank in its definition.
 @param double bal - passes a double value as balance of the account.
 @return - none
 */

Checking::Checking(double bal) : Account(bal)
{
     
}

/* 
 @member function - Checking::deposit(double amount)
 Purpose - a mutator that modifies the balance of the Checking account (savBal), by adding the 
	passed double value (amount) to the checkBal or Checking balance. It calculates, and sets the 
	new balance by calling the setBalance function, which sets the the new sum to the balance of 
	the Checking. setBalance function, and bal (called checkBal here in this context) are both 
	inherited, and therefore do not need to be redefined, but are called from the original class, 
	the Parent class, Account class.
 @param double amount - passes a double value as new amount to be added to the balance of the Savings account.
 @return - none
 */

void Checking::deposit(double amount)
{
	checkBal = getBalance();
	checkBal+= amount;
	setBalance(checkBal);

}

/* 
 @member function - Checking::withdraw(double amount)
 Purpose - a mutator that modifies the balance of the Checking account (checkBal), by subtracting the 
	passed double value (amount) to the checkBal or Checking balance. It calculates, and sets the 
	new balance by calling the setBalance function, which sets the the new sum to the balance of 
	the Checking. The setBalance function, and bal (called checkBal here in this context) are both 
	inherited, and therefore do not need to be redefined, but are called from the original class, 
	the Parent class, Account class.
 @param double amount - passes a double value as new amount to be subtracted to the balance of the Savings account.
 @return - none
 */


void Checking::withdraw(double amount)
{
	 if (amount > checkBal)
	 {
	 cout << "\nOnly " << checkBal << " is available. But trying to withdraw " << amount << ". Will need to deduct $5 from account.\n";
	 checkBal-= penalty;
	 setBalance(checkBal);
	 }
	 else
	 {
	 checkBal-= amount;
	 setBalance(checkBal);
	 }
}




/* Purpose:
 * Define, and declare the class Account, as the BASE CLASS or PARENT CLASS, 
 * which is the class to which the Derived classes, or Child classes will 
 * derive their functions, and variables from.
 * 
 * The Account class includes member functions the member functions which are by default public, 
 * or freely accessed to users of program, but are explicit in the definition 
 * as public. The private members of the class Account is the variable balance, 
 * so as not to be easily accessed by users of the program. Access is conducted only 
 * through the functions setBalance(), and getBalance().
 * 
 * Important note: the member functions, deposit, and withdraw were removed from the Account class, because
 * in the modified inheritance version, each child class, Checking, and Savings, will need its 
 * own deposit, and withdraw functions, to differentiate the balance (member variable) for 
 * each of the class. This means that when deposits/withdrawals are made, the amount of money 
 * will go to the right Account balance.
 
 @author - Deanna Laquian
 @version 1.0 4/7/2017
 
 @member functions: (which are all set as public, or freely accesses by users of the program)
	Account()
	Purpose - defualt constructor that allows users to create an object instance of the class Account, and set or initialize the balance of the Account.
        @param - none
        @return - none

	Account (double bal) 
	Purpose - constructor that also allows users to create an object instance of the class Account, but also allows to pass a parameter.
	@param bal - passes a double variable to set/initialize the balance of the account.
        @return - none
        
	void setBalance(double bal)
	Purpose - mutator, that allows users to reset balance of account to new amount specified.
        @param bal - passes as the new balance amount, in this context, called locally as bal.
        @return - none
 
	double getBalance()
	Purpose - accessor, that allows users to access, and return the balance of the account.
	@param - none
	@return - a double value of the balance of the account.

 	@member variables: (set as private, or not available for direct access by users of the program. Access is only via calling of the functions)
	double balance
	Purpose - a double value of the balance of the account which is updated each time by the functions whenever transactions are made to the accounts.
	@param - none
	@return - a double value of the balance
 */

#ifndef ACCOUNT_H
#define ACCOUNT_H


class Account
{
     public:
		Account();
		Account(double bal);
		void setBalance(double bal);
		double getBalance();

     private:
		double balance;
};

#endif

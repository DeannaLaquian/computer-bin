
/* 
 Purpose:
 Define the various member functions declared in savings.h
 @member functions - various, see below
 @param - various, see below
 @return - various, see bleow
 */

#include "savings.h"
#include <iostream>
#include <cmath>

int savBal;
const double penalty = 5.00; 

/* 
 @member function - Savings::Savings()
 Purpose - constructor, noted as a Child of the Parent class, Account. 
	It allows users to create an object instance of Savings. The definition is intentionally left blank.
 @param - none
 @return - none
 */

Savings::Savings() : Account()
{
     
}

/* 
 @member function - Savings::Savings(double bal)
 Purpose - constructor, also noted as a Child of the constructor of Parent class, Account. 
	It allow users to also create an object instance of Account, pass a double value as bal, which is balance in this context. 
	It is also intentionally left blank in its definition.
 @param double bal - passes a double value as balance of the account.
 @return - none
 */

Savings::Savings(double bal) : Account(bal)
{
     
}

/* 
 @member function - Savings::deposit(double amount)
 Purpose - a mutator that modifies the balance of the Savings account (savBal), by adding the 
	passed double value (amount) to the savBal or Savings balance. It calculates, and sets the 
	new balance by calling the setBalance function, which sets the the new sum to the balance of 
	the Savings. setBalance function, and bal (called savBal here in this context) are both 
	inherited, and therefore do not need to be redefined, but are called from the original class, 
	the Parent class, Account class.
 @param double amount - passes a double value as new amount to be added to the balance of the Savings account.
 @return - none
 */

void Savings::deposit(double amount)
{
     
    savBal = getBalance();
	savBal+= amount;
	setBalance(savBal);	

      	//Savings.getBalance()+= amount;

}

/* 
 @member function - Savings::withdraw(double amount)
 Purpose - a mutator that modifies the balance of the Savings account (savBal), by subtracting the 
	passed double value (amount) to the savBal or Savings balance. It calculates, and sets the 
	new balance by calling the setBalance function, which sets the the new sum to the balance of 
	the Savings. The setBalance function, and bal (called savBal here in this context) are both 
	inherited, and therefore do not need to be redefined, but are called from the original class, 
	the Parent class, Account class.
 @param double amount - passes a double value as new amount to be subtracted to the balance of the Savings account.
 @return - none
 */

void Savings::withdraw(double amount)
{
    
	if (amount > savBal)
	 {
	 cout << "\nOnly " << savBal << " is available. But trying to withdraw " << amount << ". Will need to deduct $5 from account.\n";
	 savBal-= penalty;
	 setBalance(savBal);
	 }
	 else
	 {
      	savBal-= amount;
	setBalance(savBal);		
	 }
}



/* 
 Purpose:
 Modify original class structure of class Bank, which had 2 member variables of the 
	datatype or belong to the class Account, namely, Checking, and Savings, into 
	an inheritance structure, wherein the Parent class is Account, and its Child 
	classes are Checking, and Savings.

 Test cases are to be printed unchanged as the former lab to see if modification 
	to the structure to inheritance was successful.
	
 Print out programmer's information such as name, course information, 
 date, and time the program is run.

 Prints out initial balance accounts set to $0, then the updated balances of both the Savings, and Checking accounting after the various transactions are made to the accounts.

 @author - Deanna Laquian
 @version 2.0 - 4/7/2017
 
 @param name - various, see below
 @return - various, see below
 
 */


#include "account.h"
#include "savings.h"
#include "checking.h"
#include "printMeFirst.h"

#include <string>
#include <iostream>
#include <iomanip>
#include <ctime>

using namespace std;

/* Purpose:
 * The 2 Child classes, Savings, and Checking initialize objects to run the test cases
 * of the inheritance program.
 * @param - none
 * @return - none
 */

Savings savings;
Checking checking;


/* 
 @function - printBalance()
 Purpose - prints balances of Savings, and/or Checking accounts
 @param - none
 @return - none
 */
 
 void printBalance()
{
     cout.width(10);
     cout << left << "Savings Account Balance:\t$\t" << savings.getBalance() << endl;
     cout << left << "Checking Account Balance:\t$\t" << checking.getBalance() << endl << endl;
}

/* 
 @function - deposit(double amount, string account)
 Purpose - to direct the recall of the correct deposit function using if statements to make the decision, of calling 
	the Checking Account deposit function, or the Savings Account deposit function
 @param amount - a double integer value to be deposited, which is added to the balance of the corresponding account.
 @oaram account - a string literal of either C or S, to determine which account the deposit will be made to.
 @return - none
 */

void deposit(double amount, string account)
{
	if(account == "C")
	checking.deposit(amount);
	
	else if(account == "S")
	savings.deposit(amount);
}
/* 
 @function - withdraw(double amount, string account)
 Purpose - to direct the recall of the correct withdraw function using if statements to make the decision, of calling 
	the Checking Account withdraw function, or the Savings Account withdraw function
 @param amount - a double integer value to be withdrawn, which is subtracted to the balance of the corresponding account.
 @oaram account - a string literal of either C or S, to determine which account the withdrawal will be made to.
 @return - none
 */
void withdraw(double amount, string account)
{
	if(account == "C")
	checking.withdraw(amount);
	
	else if(account == "S")
	savings.withdraw(amount);
}

/* 
 @function - transfer(double amount, string account)
 Purpose - a combination of a withdrawal from one account, then a deposit to another account. 
 If statements are used to make the decision, of calling the Checking Account withdraw or deposit function, or the Savings Account withdraw or deposit function
 @param amount - a double integer value to be withdrawn, then deposited from the balance of one account to the other.
 @oaram account - a string literal of either C or S, to determine which account the withdrawal will be made to first.
 @return - none
 */
void transfer(double amount, string account)
{

     if (account == "S")
	{ 
	savings.withdraw(amount);
	account = "C";
	checking.deposit(amount); 
        }

     
     else if (account == "C")
	{ 
	checking.withdraw(amount);
 	account = "S";
	savings.deposit(amount); 
        }
}

int main()
{

/* 
 Purpose:
 Print out programmer's information such as name, course information, 
 date, and time the program is run.
 
 @author - Ron Sha
 @version 1.0 1/27/2017
 
 @param name - the name of programmer
 @param courseInfo - the name, and days of course
 @return - none
 
 */

printMeFirst ("Maria Deanna Laquian", "Lab4: CS116 Thursday");


/* 
 Purpose:
 Print out inital bank balances set to $0
 @param name - none
 @return - none
 */

cout << "\nInitial bank balances: \n";

printBalance(); 


/* 
 Purpose:
 Print out tranasactions of adding money to savings, and checking account.
 Adding amount to balance using function deposit(amount, account).
 Prints updated balance.
 
 @param amount - passess amount to deposit() function
 @param account - passes string account of C or S to deposit() function
 @return - none
 
 */
cout << "\nAdding some money to accounts: \n";
cout << "\nAdding $1000 to savings \n";
cout << "Adding $2000 to checking \n";
deposit(1000, "S");
deposit(2000, "C");
printBalance();

/* 
 Purpose:
 Print out tranasactions of subtracting money from checking, then transferring money from savings to checking account. Uses withdraw(), and transfer() functions to accomplish these transactions.
 @param amount - passess amount to withdraw() function, and transfer() function
 @param account - passes string account of C or S to withdraw() function, and transfer() function
 @return - none
 
 */


cout << "\nTaking out $1500 from checking, and moving $200 from";
cout << " savings to checking.\n";

withdraw(1500, "C");
transfer(200, "S");
printBalance();

/* 
 Purpose:
 Print out tranasactions of attempt ot withdraw from Savings, but since amount is larger than current balance, withdrawal is cancelled, and a $5 penalty is subtracted from respective account.
 @param amount - passess amount to withdraw() function
 @param account - passes string account of C or S to withdraw() function
 @return - none
 
 */


cout << "\ntrying to withdraw $900 from Savings.\n";
withdraw(900, "S");
printBalance();

cout << "\ntrying to withdraw $400 from Checking.\n";
withdraw(400, "C");
printBalance();



return 0;
}


/* 
 Purpose:
 Print out programmer's information such as name, course information, 
 date, and time the program is run.
 
 @author - Ron Sha
 @version 1.0 1/27/2017
 
 @param name - the name of programmer
 @param courseInfo - the name, and days of course
 @return - none
 
 */

#include "printMeFirst.h"

void printMeFirst (string name, string courseInfo)
{
	cout << "Program written by: " << name << endl;
	cout << "Course info: " << courseInfo << endl;
	time_t now = time(0);
	char *dt = ctime(&now);
	cout << "Date: " << dt << endl;
}



#ifndef PRINTMEFIRST_H
#define PRINTMEFIRST_H

/* 
 Purpose:
 Declaration of printMeFirst function.
 
 @author - Ron Sha
 @version 1.0 1/27/2017
 
 @param name - the name of programmer
 @param courseInfo - the name, and days of course
 @return - none
 
 */


#include <iostream>
#include <string>
#include <iomanip>
#include <ctime>

using namespace std;

void printMeFirst (string name, string courseInfo);

#endif
